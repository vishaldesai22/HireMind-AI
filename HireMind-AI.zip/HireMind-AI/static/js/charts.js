// ======================================
// ATS DOUGHNUT CHART
// ======================================

const atsCanvas = document.getElementById('atsChart');

if (atsCanvas) {

    new Chart(atsCanvas, {

        type: 'doughnut',

        data: {

            labels: ['ATS Score', 'Remaining'],

            datasets: [{

                data: [atsScore, 100 - atsScore],

                borderWidth: 2
            }]
        },

        options: {

            responsive: true,

            plugins: {

                legend: {

                    labels: {
                        color: 'white'
                    }
                }
            }
        }
    });
}