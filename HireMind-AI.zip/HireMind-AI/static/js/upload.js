const uploadInput = document.querySelector('input[type="file"]');

if (uploadInput) {

    uploadInput.addEventListener('change', () => {

        alert('Resume selected successfully');
    });
}