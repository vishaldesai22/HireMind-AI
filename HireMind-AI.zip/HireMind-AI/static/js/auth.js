const forms = document.querySelectorAll('form');

forms.forEach(form => {

    form.addEventListener('submit', () => {

        console.log('Form Submitted');
    });
});