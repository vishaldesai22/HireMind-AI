import smtplib

from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


def send_reset_email(
    sender_email,
    app_password,
    receiver_email,
    reset_link
):

    subject = (
        "HireMind AI Password Reset"
    )

    body = f'''
Click the link below to reset your password:

{reset_link}

This link expires in 15 minutes.
'''

    msg = MIMEMultipart()

    msg['From'] = sender_email

    msg['To'] = receiver_email

    msg['Subject'] = subject

    msg.attach(
        MIMEText(body, 'plain')
    )

    server = smtplib.SMTP(
        'smtp.gmail.com',
        587
    )

    server.starttls()

    server.login(
        sender_email,
        app_password
    )

    server.send_message(msg)

    server.quit()