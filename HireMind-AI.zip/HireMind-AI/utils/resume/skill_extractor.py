SKILLS = [
    'python',
    'flask',
    'django',
    'sql',
    'mysql',
    'html',
    'css',
    'javascript',
    'react',
    'nodejs',
    'machine learning',
    'tensorflow',
    'pandas',
    'numpy',
    'excel',
    'power bi',
    'aws',
    'docker',
    'kubernetes',
    'api'
]


def extract_skills(text):

    text = text.lower()

    found_skills = []

    for skill in SKILLS:

        if skill in text:

            found_skills.append(skill)

    return list(set(found_skills))