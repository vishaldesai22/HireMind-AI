from PyPDF2 import PdfReader
from docx import Document


def extract_text(filepath):

    text = ""

    if filepath.endswith('.pdf'):

        reader = PdfReader(filepath)

        for page in reader.pages:

            extracted = page.extract_text()

            if extracted:
                text += extracted

    elif filepath.endswith('.docx'):

        doc = Document(filepath)

        for para in doc.paragraphs:

            text += para.text

    return text.lower()