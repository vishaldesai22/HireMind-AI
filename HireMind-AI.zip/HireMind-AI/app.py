import tempfile
from flask import (
    Flask,
    render_template,
    request,
    redirect,
    session,
    flash,
    send_file
)

import random
from werkzeug.security import (
    generate_password_hash,
    check_password_hash
)

from werkzeug.utils import secure_filename

import sqlite3
import os
import secrets
import zipfile

from datetime import (
    datetime,
    timedelta
)

# ======================================
# IMPORTS
# ======================================

from utils.resume.parser import extract_text

from utils.resume.skill_extractor import (
    extract_skills
)

from utils.resume.name_extractor import (
    extract_candidate_name
)

from utils.ai_engine.recommendation_engine import (
    get_missing_skills,
    generate_recommendations
)

from utils.reports.pdf_report import (
    generate_pdf_report
)

from utils.helpers.email_sender import (
    send_email_report
)

from utils.helpers.reset_email import (
    send_reset_email
)


# ======================================
# INTERVIEW QUESTIONS
# ======================================

INTERVIEW_QUESTIONS = {

    'Backend Developer': [

        'Explain REST API.',
        'What is Flask?',
        'Difference between SQL and NoSQL?',
        'What is JWT authentication?',
        'Explain Python decorators.'
    ],

    'Frontend Developer': [

        'Difference between var let and const?',
        'What is React?',
        'Explain Virtual DOM.',
        'Difference between HTML and HTML5?',
        'What is responsive design?'
    ],

    'ML Engineer': [

        'What is overfitting?',
        'Difference between AI and ML?',
        'Explain supervised learning.',
        'What is feature engineering?',
        'What is regression?'
    ],

    'General Candidate': [

        'Tell us about yourself.',
        'Why should we hire you?',
        'What are your strengths?',
        'What are your weaknesses?',
        'Where do you see yourself in 5 years?'
    ]
}

# ======================================
# FLASK CONFIG
# ======================================

app = Flask(__name__)

app.secret_key = 'hiremind_secret_key'

UPLOAD_FOLDER = (
    'static/assets/uploads/resumes'
)

PDF_FOLDER = (
    'static/assets/exports/pdf'
)

ZIP_FOLDER = (
    'static/assets/exports/zip'
)

app.config['UPLOAD_FOLDER'] = (
    UPLOAD_FOLDER
)

os.makedirs(
    UPLOAD_FOLDER,
    exist_ok=True
)

os.makedirs(
    PDF_FOLDER,
    exist_ok=True
)

os.makedirs(
    ZIP_FOLDER,
    exist_ok=True
)

# ======================================
# DATABASE CONNECTION
# ======================================

def get_db_connection():

    conn = sqlite3.connect(
        'database.db'
    )

    conn.row_factory = sqlite3.Row

    return conn

# ======================================
# DATABASE INITIALIZATION
# ======================================

def init_db():

    conn = get_db_connection()

    cursor = conn.cursor()

    # USERS TABLE

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        username TEXT NOT NULL,

        email TEXT UNIQUE NOT NULL,

        contact TEXT NOT NULL,

        password TEXT NOT NULL,

        role TEXT DEFAULT 'user'
    )
    ''')

    # RESUMES TABLE

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS resumes (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        user_id INTEGER,

        resume_name TEXT,

        resume_path TEXT,

        pdf_filename TEXT,

        ats_score INTEGER,

        role_prediction TEXT,

        interview_readiness TEXT,

        skills TEXT,

        status TEXT DEFAULT 'Pending',

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # PASSWORD RESET TABLE

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS password_resets (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        email TEXT,

        token TEXT,

        expires_at TEXT
    )
    ''')
    
    
    
   # INTERVIEW RESULTS TABLE

    cursor.execute('''
    CREATE TABLE IF NOT EXISTS interview_results (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        user_id INTEGER,

        question TEXT,

        answer TEXT,

        score INTEGER,

        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    ''')

    # DEFAULT ADMIN

    admin = cursor.execute(
        '''
        SELECT *
        FROM users
        WHERE email=?
        ''',
        ('admin@hiremind.com',)
    ).fetchone()

    if not admin:

        cursor.execute(
            '''
            INSERT INTO users
            (
                username,
                email,
                contact,
                password,
                role
            )
            VALUES (?,?,?,?,?)
            ''',
            (
                'admin',
                'admin@hiremind.com',
                '9999999999',
                generate_password_hash(
                    'admin'
                ),
                'admin'
            )
        )

    conn.commit()

    conn.close()

# ======================================
# HOME
# ======================================

@app.route('/')
def home():

    return render_template(
        'index.html'
    )

# ======================================
# REGISTER
# ======================================

@app.route(
    '/register',
    methods=['GET', 'POST']
)
def register():

    if request.method == 'POST':

        username = request.form['username']

        email = request.form['email']

        contact = request.form['contact']

        password = request.form['password']

        hashed_password = (
            generate_password_hash(
                password
            )
        )

        conn = get_db_connection()

        existing_user = conn.execute(
            '''
            SELECT *
            FROM users
            WHERE email=?
            ''',
            (email,)
        ).fetchone()

        if existing_user:

            flash(
                'Email already exists'
            )

            conn.close()

            return redirect('/register')

        conn.execute(
            '''
            INSERT INTO users
            (
                username,
                email,
                contact,
                password
            )
            VALUES (?,?,?,?)
            ''',
            (
                username,
                email,
                contact,
                hashed_password
            )
        )

        conn.commit()

        conn.close()

        flash(
            'Registration Successful'
        )

        return redirect('/login')

    return render_template(
        'auth/register.html'
    )

# ======================================
# LOGIN
# ======================================

@app.route(
    '/login',
    methods=['GET', 'POST']
)
def login():

    if request.method == 'POST':

        email = request.form['email']

        password = request.form['password']

        conn = get_db_connection()

        user = conn.execute(
            '''
            SELECT *
            FROM users
            WHERE email=?
            ''',
            (email,)
        ).fetchone()

        conn.close()

        if (
            user
            and
            check_password_hash(
                user['password'],
                password
            )
        ):

            session['user_id'] = (
                user['id']
            )

            session['username'] = (
                user['username']
            )

            session['role'] = (
                user['role']
            )

            if user['role'] == 'admin':

                return redirect(
                    '/admin-dashboard'
                )

            return redirect('/dashboard')

        flash(
            'Invalid Email or Password'
        )

        return redirect('/login')

    return render_template(
        'auth/login.html'
    )

# ======================================
# FORGOT PASSWORD
# ======================================

@app.route(
    '/forgot-password',
    methods=['GET', 'POST']
)
def forgot_password():

    if request.method == 'POST':

        email = request.form['email']

        conn = get_db_connection()

        user = conn.execute(
            '''
            SELECT *
            FROM users
            WHERE email=?
            ''',
            (email,)
        ).fetchone()

        if not user:

            flash('Email not found')

            conn.close()

            return redirect('/forgot-password')

        token = secrets.token_urlsafe(
            32
        )

        expires_at = (
            datetime.utcnow()
            +
            timedelta(minutes=15)
        ).isoformat()

        conn.execute(
            '''
            INSERT INTO password_resets
            (
                email,
                token,
                expires_at
            )
            VALUES (?,?,?)
            ''',
            (
                email,
                token,
                expires_at
            )
        )

        conn.commit()

        conn.close()

        reset_link = (
            f"{request.host_url}reset-password/{token}"
        )

        try:

            send_reset_email(
                'vishaldesaivd143@gmail.com',
                'wxzjtmmjsqgdcivj',
                email,
                reset_link
            )

            flash(
                'Password reset email sent'
            )

        except Exception as e:

            print(
                'RESET EMAIL ERROR:',
                str(e)
            )

            flash(
                'Failed to send reset email'
            )

        return redirect('/login')

    return render_template(
        'auth/forgot_password.html'
    )

# ======================================
# RESET PASSWORD
# ======================================

@app.route(
    '/reset-password/<token>',
    methods=['GET', 'POST']
)
def reset_password(token):

    conn = get_db_connection()

    reset_data = conn.execute(
        '''
        SELECT *
        FROM password_resets
        WHERE token=?
        ''',
        (token,)
    ).fetchone()

    if not reset_data:

        conn.close()

        flash('Invalid reset link')

        return redirect('/login')

    expires_at = datetime.fromisoformat(
        reset_data['expires_at']
    )

    if datetime.utcnow() > expires_at:

        conn.close()

        flash('Reset link expired')

        return redirect('/forgot-password')

    if request.method == 'POST':

        password = request.form['password']

        confirm_password = (
            request.form['confirm_password']
        )

        if password != confirm_password:

            flash(
                'Passwords do not match'
            )

            return redirect(
                f'/reset-password/{token}'
            )

        hashed_password = (
            generate_password_hash(
                password
            )
        )

        conn.execute(
            '''
            UPDATE users
            SET password=?
            WHERE email=?
            ''',
            (
                hashed_password,
                reset_data['email']
            )
        )

        conn.execute(
            '''
            DELETE FROM password_resets
            WHERE token=?
            ''',
            (token,)
        )

        conn.commit()

        conn.close()

        flash(
            'Password updated successfully'
        )

        return redirect('/login')

    conn.close()

    return render_template(
        'auth/reset_password.html'
    )

# ======================================
# DASHBOARD
# ======================================

@app.route('/dashboard')
def dashboard():

    if 'user_id' not in session:

        return redirect('/login')

    return render_template(
        'user/dashboard.html'
    )

# ======================================
# PROFILE
# ======================================

@app.route('/profile')
def profile():

    if 'user_id' not in session:

        return redirect('/login')

    conn = get_db_connection()

    user = conn.execute(
        '''
        SELECT *
        FROM users
        WHERE id=?
        ''',
        (session['user_id'],)
    ).fetchone()

    total_resumes = conn.execute(
        '''
        SELECT COUNT(*)
        FROM resumes
        WHERE user_id=?
        ''',
        (session['user_id'],)
    ).fetchone()[0]

    highest_ats = conn.execute(
        '''
        SELECT MAX(ats_score)
        FROM resumes
        WHERE user_id=?
        ''',
        (session['user_id'],)
    ).fetchone()[0]

    latest_resume = conn.execute(
        '''
        SELECT *
        FROM resumes
        WHERE user_id=?
        ORDER BY id DESC
        LIMIT 1
        ''',
        (session['user_id'],)
    ).fetchone()

    conn.close()

    latest_role = 'No Data'

    if latest_resume:

        latest_role = (
            latest_resume[
                'role_prediction'
            ]
        )

    if not highest_ats:

        highest_ats = 0

    return render_template(
        'user/profile.html',
        user=user,
        total_resumes=total_resumes,
        highest_ats=highest_ats,
        latest_role=latest_role
    )

# ======================================
# UPLOAD RESUME
# ======================================

@app.route(
    '/upload',
    methods=['GET', 'POST']
)
def upload():

    if 'user_id' not in session:

        return redirect('/login')

    if request.method == 'POST':

        ALLOWED_EXTENSIONS = {
            'pdf',
            'docx'
        }

        MAX_FILE_SIZE = (
            5 * 1024 * 1024
        )

        if 'resume' not in request.files:

            flash('No file uploaded')

            return redirect('/upload')

        file = request.files['resume']

        if file.filename == '':

            flash('No selected file')

            return redirect('/upload')

        file_ext = (
            file.filename
            .rsplit('.', 1)[1]
            .lower()
        )

        if file_ext not in ALLOWED_EXTENSIONS:

            flash(
                'Only PDF and DOCX files allowed'
            )

            return redirect('/upload')

        file.seek(0, os.SEEK_END)

        file_size = file.tell()

        file.seek(0)

        if file_size > MAX_FILE_SIZE:

            flash(
                'File exceeds 5MB limit'
            )

            return redirect('/upload')

        filename = secure_filename(
            file.filename
        )

        filepath = os.path.join(
            app.config['UPLOAD_FOLDER'],
            filename
        )

        file.save(filepath)

        resume_text = extract_text(
            filepath
        )

        candidate_name = (
            extract_candidate_name(
                resume_text
            )
        )

        found_skills = (
            extract_skills(
                resume_text
            )
        )

        skill_score = min(
            len(found_skills) * 4,
            
            40
        )

        project_score = 20

        experience_score = 20

        education_score = 20
        
        formatting_score = 10

        ats_score = min(
            skill_score
            +
            project_score
            +
            experience_score
            +
            education_score
            +
            formatting_score,
            100
        )

        if (
            'python' in found_skills
            and
            'flask' in found_skills
        ):

            role_prediction = (
                'Backend Developer'
            )

        elif (
            'react' in found_skills
            and
            'javascript' in found_skills
        ):

            role_prediction = (
                'Frontend Developer'
            )

        elif (
            'machine learning'
            in found_skills
        ):

            role_prediction = (
                'ML Engineer'
            )

        else:

            role_prediction = (
                'General Candidate'
            )

        if ats_score >= 80:

            interview_readiness = (
                'Highly Ready'
            )

        elif ats_score >= 60:

            interview_readiness = (
                'Moderately Ready'
            )

        else:

            interview_readiness = (
                'Needs Improvement'
            )

        missing_skills = (
            get_missing_skills(
                role_prediction,
                found_skills
            )
        )

        recommendations = (
            generate_recommendations(
                missing_skills
            )
        )

        session['missing_skills'] = (
            missing_skills
        )

        session['recommendations'] = (
            recommendations
        )

        # PDF

        timestamp = datetime.now().strftime(
            '%Y%m%d_%H%M%S'
        )

        pdf_filename = (
            f"HireMind_Report_{timestamp}.pdf"
        )

        pdf_path = os.path.join(
            PDF_FOLDER,
            pdf_filename
        )

        generate_pdf_report(
            pdf_path,
            candidate_name,
            ats_score,
            role_prediction,
            interview_readiness,
            found_skills,
            missing_skills,
            recommendations
        )

        session['latest_pdf'] = (
            pdf_filename
        )

        # EMAIL REPORT

        conn_user = get_db_connection()

        user = conn_user.execute(
            '''
            SELECT *
            FROM users
            WHERE id=?
            ''',
            (session['user_id'],)
        ).fetchone()

        conn_user.close()

        try:

            send_email_report(
                'vishaldesaivd143@gmail.com',
                'wxzjtmmjsqgdcivj',
                user['email'],
                pdf_path
            )

        except Exception as e:

            print(
                'EMAIL ERROR:',
                str(e)
            )

        # SAVE DB

        conn = get_db_connection()

        conn.execute(
            '''
            INSERT INTO resumes
            (
                user_id,
                resume_name,
                resume_path,
                pdf_filename,
                ats_score,
                role_prediction,
                interview_readiness,
                skills,
                status
            )
            VALUES (?,?,?,?,?,?,?,?,?)
            ''',
            (
                session['user_id'],
                filename,
                filepath,
                pdf_filename,
                ats_score,
                role_prediction,
                interview_readiness,
                ','.join(found_skills),
                'Pending'
            )
        )

        conn.commit()

        conn.close()

        return redirect('/results')

    return render_template(
        'user/upload.html'
    )

# ======================================
# RESULTS
# ======================================

@app.route('/results')
def results():

    if 'user_id' not in session:

        return redirect('/login')

    conn = get_db_connection()

    resume = conn.execute(
        '''
        SELECT *
        FROM resumes
        WHERE user_id=?
        ORDER BY id DESC
        LIMIT 1
        ''',
        (session['user_id'],)
    ).fetchone()

    conn.close()

    return render_template(
        'user/results.html',
        resume=resume
    )

# ======================================
# DOWNLOAD REPORT
# ======================================

@app.route('/download-report')
def download_report():

    if 'user_id' not in session:

        return redirect('/login')

    if 'latest_pdf' not in session:

        flash('No report found')

        return redirect('/results')

    pdf_path = os.path.join(
        PDF_FOLDER,
        session['latest_pdf']
    )

    return send_file(
        pdf_path,
        as_attachment=True
    )

# ======================================
# HISTORY
# ======================================

@app.route('/history')
def history():

    if 'user_id' not in session:

        return redirect('/login')

    conn = get_db_connection()

    resumes = conn.execute(
        '''
        SELECT *
        FROM resumes
        WHERE user_id=?
        ORDER BY id DESC
        ''',
        (session['user_id'],)
    ).fetchall()

    conn.close()

    return render_template(
        'user/history.html',
        resumes=resumes
    )

# ======================================
# CHANGE PASSWORD
# ======================================

@app.route(
    '/change-password',
    methods=['POST']
)
def change_password():

    if 'user_id' not in session:

        return redirect('/login')

    old_password = request.form['old_password']

    new_password = request.form['new_password']

    confirm_password = (
        request.form['confirm_password']
    )

    if new_password != confirm_password:

        flash('Passwords do not match')

        return redirect('/profile')

    conn = get_db_connection()

    user = conn.execute(
        '''
        SELECT *
        FROM users
        WHERE id=?
        ''',
        (session['user_id'],)
    ).fetchone()

    if not check_password_hash(
        user['password'],
        old_password
    ):

        flash('Old password incorrect')

        conn.close()

        return redirect('/profile')

    hashed_password = (
        generate_password_hash(
            new_password
        )
    )

    conn.execute(
        '''
        UPDATE users
        SET password=?
        WHERE id=?
        ''',
        (
            hashed_password,
            session['user_id']
        )
    )

    conn.commit()

    conn.close()

    flash(
        'Password updated successfully'
    )

    return redirect('/profile')

# ======================================
# UPDATE STATUS
# ======================================

@app.route('/update-status/<int:id>/<status>')
def update_status(id, status):

    if 'user_id' not in session:

        return redirect('/login')

    if session['role'] != 'admin':

        return redirect('/dashboard')

    conn = get_db_connection()

    conn.execute(
        '''
        UPDATE resumes
        SET status=?
        WHERE id=?
        ''',
        (
            status,
            id
        )
    )

    conn.commit()

    conn.close()

    flash('Resume status updated')

    return redirect('/admin-dashboard')
# ======================================
# DOWNLOAD SELECTED REPORTS
# ======================================
@app.route('/download-selected-reports')
def download_selected_reports():

    conn = get_db_connection()

    selected_resumes = conn.execute(
        '''
        SELECT *
        FROM resumes
        WHERE status='Selected'
        '''
    ).fetchall()

    conn.close()

    import tempfile

    temp_dir = tempfile.gettempdir()

    zip_path = os.path.join(
        temp_dir,
        'Selected_Candidates_Reports.zip'
    )

    with zipfile.ZipFile(
        zip_path,
        'w',
        zipfile.ZIP_DEFLATED
    ) as zipf:

        for resume in selected_resumes:

            print("PDF FILE:", resume['pdf_filename'])

            if resume['pdf_filename']:

                file_path = os.path.join(
                    PDF_FOLDER,
                    resume['pdf_filename']
                )

                print("FULL PATH:", file_path)
                print("FILE EXISTS:", os.path.exists(file_path))

                if os.path.exists(file_path):

                    zipf.write(
                        file_path,
                        arcname=resume['pdf_filename']
                    )

    print("=" * 50)
    print("DOWNLOAD ROUTE HIT")
    print("Selected resumes:", len(selected_resumes))
    print("ZIP PATH:", zip_path)
    print("ZIP EXISTS:", os.path.exists(zip_path))

    if os.path.exists(zip_path):
        print("ZIP SIZE:", os.path.getsize(zip_path))

    print("=" * 50)

    return send_file(
        zip_path,
        as_attachment=True,
        download_name='Selected_Candidates_Reports.zip',
        mimetype='application/zip'
    )
# ======================================
# INTERVIEW SIMULATOR
# ======================================

@app.route(
    '/interview',
    methods=['GET', 'POST']
)
def interview():

    if 'user_id' not in session:

        return redirect('/login')
    role = session.get(
        'predicted_role',
        'General Candidate'
    )
    
    questions = INTERVIEW_QUESTIONS.get(
        role,
        INTERVIEW_QUESTIONS['General Candidate']
    )


    conn = get_db_connection()
    if request.method == 'POST':

        total_score = 0

        for question in questions:

            answer = request.form.get(
                question,
                ''
            )

            score = random.randint(6, 10)

            total_score += score

            conn.execute(
                '''
                INSERT INTO interview_results
                (
                    user_id,
                    question,
                    answer,
                    score
                )
                VALUES (?, ?, ?, ?)
                ''',
                (
                    session['user_id'],
                    question,
                    answer,
                    score
                )
            )

        conn.commit()

        conn.close()

        average_score = round(
            total_score / len(questions),
            1
        )

        return render_template(
            'user/interview_result.html',
            average_score=average_score
        )

    conn.close()

    return render_template(
        'user/interview.html',
        questions=questions,
        role=role
    )

# ======================================
# ADMIN DASHBOARD
# ======================================

@app.route('/admin-dashboard')
def admin_dashboard():

    if 'user_id' not in session:

        return redirect('/login')

    if session['role'] != 'admin':

        return redirect('/dashboard')

    conn = get_db_connection()

    users = conn.execute(
        '''
        SELECT *
        FROM users
        '''
    ).fetchall()

    resumes = conn.execute(
        '''
        SELECT *
        FROM resumes
        ORDER BY id DESC
        '''
    ).fetchall()

    total_users = conn.execute(
        '''
        SELECT COUNT(*)
        FROM users
        '''
    ).fetchone()[0]

    total_resumes = conn.execute(
        '''
        SELECT COUNT(*)
        FROM resumes
        '''
    ).fetchone()[0]

    selected_count = conn.execute(
        '''
        SELECT COUNT(*)
        FROM resumes
        WHERE status='Selected'
        '''
    ).fetchone()[0]

    rejected_count = conn.execute(
        '''
        SELECT COUNT(*)
        FROM resumes
        WHERE status='Rejected'
        '''
    ).fetchone()[0]

    avg_ats = conn.execute(
        '''
        SELECT AVG(ats_score)
        FROM resumes
        '''
    ).fetchone()[0]

    conn.close()

    return render_template(
        'admin/admin_dashboard.html',
        users=users,
        resumes=resumes,
        total_users=total_users,
        total_resumes=total_resumes,
        selected_count=selected_count,
        rejected_count=rejected_count,
        avg_ats=round(avg_ats or 0, 2)
    )

# ======================================
# DELETE USER
# ======================================

@app.route('/delete-user/<int:id>')
def delete_user(id):

    if 'user_id' not in session:

        return redirect('/login')

    if session['role'] != 'admin':

        return redirect('/dashboard')

    conn = get_db_connection()

    conn.execute(
        '''
        DELETE FROM users
        WHERE id=?
        ''',
        (id,)
    )

    conn.commit()

    conn.close()

    flash(
        'User deleted successfully'
    )

    return redirect('/admin-dashboard')


# ======================================
# LOGOUT
# ======================================

@app.route('/logout')
def logout():

    session.clear()

    return redirect('/login')

# ======================================
# RUN APP
# ======================================

if __name__ == '__main__':

    init_db()

    app.run(
        host='0.0.0.0',
        port=8080,
        debug=False
    )