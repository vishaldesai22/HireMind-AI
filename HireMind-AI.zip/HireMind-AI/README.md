# HireMind AI

HireMind AI is an advanced AI Resume Analyzer and Recruitment Intelligence platform.

## Features

- Authentication System
- ATS Resume Analysis
- Resume Parsing
- AI Recommendations
- Missing Skills Detection
- Admin Analytics
- PDF Report Generation
- Email Automation
- Resume History Tracking

## Technologies Used

- Flask
- SQLite
- HTML
- CSS
- JavaScript
- Chart.js

## Run Project

```bash
pip install -r requirements.txt
python app.py


---

# 13. `requirements.txt`

```txt
flask
werkzeug
reportlab
PyPDF2
python-docx


Admin login credentials 

Email: admin@hiremind.com
Password: admin